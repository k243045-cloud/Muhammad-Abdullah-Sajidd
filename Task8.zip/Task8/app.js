document.addEventListener('DOMContentLoaded', () => {
    const partnerGrid = document.getElementById('partner-grid');
    const searchInput = document.getElementById('search-input');
    const filterButtons = document.querySelectorAll('.filter-btn');
    
    const loadingState = document.getElementById('loading-state');
    const errorState = document.getElementById('error-state');
    const emptyState = document.getElementById('empty-state');

    let corporateMasterDataset = [];
    let activeFilterCategory = 'All';
    let activeSearchString = '';

    // Asynchronously fetch team.json resource configuration node mapping layers
    async function loadEcosystemRegistry() {
        try {
            const response = await fetch('team.json');
            if (!response.ok) throw new Error(`HTTP network error: status code ${response.status}`);
            
            corporateMasterDataset = await response.json();
            loadingState.classList.add('hidden');
            processInterfaceFilters();
        } catch (error) {
            console.error('Data system synchronization failure logged:', error);
            loadingState.classList.add('hidden');
            errorState.classList.remove('hidden');
        }
    }

    // Pipeline Engine: Maps incoming strings and data filter properties simultaneously
    function processInterfaceFilters() {
        const matchingNodes = corporateMasterDataset.filter(node => {
            
            // 1. Complex Multi-Role Categorization Rule Mapping Logic
            let matchesCategory = false;
            const cardRole = node.role.toLowerCase();

            if (activeFilterCategory === 'All') {
                matchesCategory = true;
            } else if (activeFilterCategory === 'Software') {
                matchesCategory = cardRole.includes('software development');
            } else if (activeFilterCategory === 'Consulting') {
                matchesCategory = cardRole.includes('consulting');
            } else if (activeFilterCategory === 'Data') {
                matchesCategory = cardRole.includes('data services');
            } else if (activeFilterCategory === 'AI') {
                matchesCategory = cardRole.includes('technology, information') || cardRole.includes('research services');
            }

            // 2. Text Search Match Checking Across Card Fields
            const sanitizedQuery = activeSearchString.toLowerCase().trim();
            const matchesSearch = sanitizedQuery === '' || 
                                  node.name.toLowerCase().includes(sanitizedQuery) ||
                                  node.role.toLowerCase().includes(sanitizedQuery) ||
                                  node.bio.toLowerCase().includes(sanitizedQuery);

            return matchesCategory && matchesSearch;
        });

        // Toggle state indicators visibility depending on target result outputs
        if (matchingNodes.length === 0) {
            partnerGrid.classList.add('hidden');
            emptyState.classList.remove('hidden');
        } else {
            emptyState.classList.add('hidden');
            partnerGrid.classList.remove('hidden');
            generateCardLayouts(matchingNodes);
        }
    }

    // Card View DOM Template Generation Engine
    function generateCardLayouts(elements) {
        let gridHTML = '';
        
        elements.forEach(item => {
            gridHTML += `
                <article class="corporate-card">
                    <div class="brand-image-holder">
                        <img src="${item.image_url}" alt="${item.name} organizational master logo brand asset" loading="lazy">
                    </div>
                    <div class="card-body">
                        <h3>${item.name}</h3>
                        <span class="role-badge">${item.role}</span>
                        <p class="bio-desc">${item.bio}</p>
                        <div class="card-footer">
                            <a href="${item.social_links.linkedin}" class="link-btn" target="_blank" rel="noopener noreferrer">LinkedIn Platform</a>
                            <a href="${item.social_links.github}" class="link-btn" target="_blank" rel="noopener noreferrer">GitHub Profile</a>
                        </div>
                    </div>
                </article>
            `;
        });
        partnerGrid.innerHTML = gridHTML;
    }

    // Real-Time Interaction Observers
    searchInput.addEventListener('input', (e) => {
        activeSearchString = e.target.value;
        processInterfaceFilters();
    });

    filterButtons.forEach(btn => {
        btn.addEventListener('click', (e) => {
            filterButtons.forEach(element => element.classList.remove('active'));
            e.target.classList.add('active');
            activeFilterCategory = e.target.getAttribute('data-category');
            processInterfaceFilters();
        });
    });

    loadEcosystemRegistry();
});
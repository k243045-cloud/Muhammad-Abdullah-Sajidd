const db = require('../config/db');

class About {
    // Get the single about record (assumes only one row with id=1)
    static async get() {
        const [rows] = await db.query('SELECT * FROM about LIMIT 1');
        return rows[0] || null;
    }

    // Update the about record (assumes id=1)
    static async update(data) {
        const { company_name, description, mission, vision, image_url } = data;
        const [result] = await db.query(
            `UPDATE about SET 
                company_name = ?, 
                description = ?, 
                mission = ?, 
                vision = ?, 
                image_url = ?,
                updated_at = CURRENT_TIMESTAMP
            WHERE id = 1`,
            [company_name, description, mission, vision, image_url]
        );
        return result;
    }

    // Optional: insert initial record if none exists
    static async init() {
        const existing = await this.get();
        if (!existing) {
            await db.query(
                `INSERT INTO about (company_name, description, mission, vision, image_url) 
                 VALUES (?, ?, ?, ?, ?)`,
                ['Your Company', 'Description', 'Mission', 'Vision', '']
            );
        }
    }
}

module.exports = About;
const express = require('express');
const router = express.Router();
const About = require('../models/About');
const upload = require('../middleware/upload');
const path = require('path');

// GET /api/about
router.get('/', async (req, res) => {
    try {
        const about = await About.get();
        if (!about) {
            return res.status(404).json({ success: false, message: 'About content not found' });
        }
        res.json({ success: true, data: about });
    } catch (err) {
        console.error(err);
        res.status(500).json({ success: false, message: 'Server error' });
    }
});

// PUT /api/about
router.put('/', async (req, res) => {
    const { company_name, description, mission, vision, image_url } = req.body;

    // Validation
    if (!company_name || !description || !mission || !vision) {
        return res.status(400).json({
            success: false,
            message: 'Company name, description, mission, and vision are required'
        });
    }

    try {
        const result = await About.update({ company_name, description, mission, vision, image_url: image_url || '' });
        if (result.affectedRows === 0) {
            return res.status(404).json({ success: false, message: 'About record not found' });
        }
        const updated = await About.get();
        res.json({ success: true, message: 'About page updated successfully', data: updated });
    } catch (err) {
        console.error(err);
        res.status(500).json({ success: false, message: 'Server error' });
    }
});

// POST /api/about/upload
router.post('/upload', upload.single('image'), (req, res) => {
    try {
        if (!req.file) {
            return res.status(400).json({ success: false, message: 'No image file uploaded' });
        }
        // Construct the URL (adjust host/port as needed)
        const imageUrl = `${req.protocol}://${req.get('host')}/uploads/${req.file.filename}`;
        res.json({ success: true, data: { imageUrl } });
    } catch (err) {
        console.error(err);
        res.status(500).json({ success: false, message: 'Upload failed' });
    }
});

// Serve static files from uploads folder
router.use('/uploads', express.static(path.join(__dirname, '../uploads')));

module.exports = router;
require('dotenv').config();
const express = require('express');
const cors = require('cors');
const path = require('path');
const aboutRoutes = require('./routes/about');
const About = require('./models/About');

const app = express();
const PORT = process.env.PORT || 5000;

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Serve static files from frontend (if you want to serve from backend)
// Alternatively, you can serve frontend separately.
app.use(express.static(path.join(__dirname, '../frontend')));

// API routes
app.use('/api/about', aboutRoutes);

// Initialize database (ensure record exists)
(async () => {
    try {
        await About.init();
        console.log('Database initialized successfully.');
    } catch (err) {
        console.error('Database initialization error:', err);
    }
})();

// Start server
app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});
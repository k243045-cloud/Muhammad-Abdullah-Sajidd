-- Create database (optional; adjust as needed)
CREATE DATABASE IF NOT EXISTS cms_about;
USE cms_about;

-- Create about table
CREATE TABLE IF NOT EXISTS about (
    id INT AUTO_INCREMENT PRIMARY KEY,
    company_name VARCHAR(255) NOT NULL,
    description TEXT NOT NULL,
    mission TEXT NOT NULL,
    vision TEXT NOT NULL,
    image_url VARCHAR(512),
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Insert a default record (optional)
INSERT INTO about (company_name, description, mission, vision, image_url)
VALUES (
    'Your Company Name',
    'Welcome to our company. We are dedicated to providing the best services.',
    'To empower every person and organization on the planet to achieve more.',
    'A world where technology enhances human potential.',
    'https://via.placeholder.com/600x400'
);
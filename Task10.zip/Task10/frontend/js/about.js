// about.js - for public about page

document.addEventListener('DOMContentLoaded', () => {
    const pageContent = document.getElementById('pageContent');
    const API_BASE = '/api/about';

    async function fetchAbout() {
        pageContent.innerHTML = `
            <div class="loading-overlay">
                <div class="spinner spinner-dark"></div>
                <span>Loading company information…</span>
            </div>
        `;

        try {
            const response = await fetch(API_BASE);
            const result = await response.json();
            if (!response.ok) throw new Error(result.message || 'Failed to load');
            const about = result.data;

            const imageHtml = about.image_url ?
                `<img src="${about.image_url}" alt="${about.company_name}" loading="lazy" />` :
                `<div class="placeholder-img">📷 No image set</div>`;

            pageContent.innerHTML = `
                <div class="card">
                    <div class="about-hero" style="display:flex; flex-direction:row; gap:32px; align-items:flex-start;">
                        <div class="about-text" style="flex:2;">
                            <h1 class="company-name" style="font-size:2.2rem; font-weight:700; color:#0f172a; margin-bottom:8px;">
                                ${escapeHtml(about.company_name)} <small style="font-weight:400; font-size:1rem; color:#64748b;">— About Us</small>
                            </h1>
                            <div class="description-text" style="font-size:1.05rem; color:#334155; margin-bottom:24px; line-height:1.7;">
                                ${about.description || '<em>No description provided.</em>'}
                            </div>
                            <div class="mission-vision" style="display:grid; grid-template-columns:1fr 1fr; gap:24px; margin-top:8px;">
                                <div class="mv-block">
                                    <h3 style="font-size:1rem; font-weight:600; text-transform:uppercase; letter-spacing:0.04em; color:#64748b; margin-bottom:6px;">🎯 Mission</h3>
                                    <p style="color:#1e293b; line-height:1.6;">${about.mission || '<em>Not set yet.</em>'}</p>
                                </div>
                                <div class="mv-block">
                                    <h3 style="font-size:1rem; font-weight:600; text-transform:uppercase; letter-spacing:0.04em; color:#64748b; margin-bottom:6px;">👁️ Vision</h3>
                                    <p style="color:#1e293b; line-height:1.6;">${about.vision || '<em>Not set yet.</em>'}</p>
                                </div>
                            </div>
                            <div class="updated-at" style="font-size:0.85rem; color:#94a3b8; margin-top:24px; border-top:1px solid #eef2f6; padding-top:16px;">
                                Last updated: ${about.updated_at ? new Date(about.updated_at).toLocaleString() : 'Never'}
                            </div>
                        </div>
                        <div class="about-image" style="flex:1; min-width:260px;">
                            ${imageHtml}
                        </div>
                    </div>
                </div>
            `;
        } catch (err) {
            pageContent.innerHTML = `
                <div class="card" style="text-align:center; padding:48px 20px;">
                    <div style="font-size:2.4rem; margin-bottom:12px;">⚠️</div>
                    <h2 style="color:#ef4444; font-weight:600;">Failed to load content</h2>
                    <p style="color:#64748b; margin-top:6px;">${escapeHtml(err.message)}</p>
                    <button class="btn btn-primary mt-16" onclick="location.reload()">🔄 Retry</button>
                </div>
            `;
            showToast('Error: ' + err.message, 'error');
        }
    }

    // Helper
    function escapeHtml(str) {
        if (!str) return '';
        const div = document.createElement('div');
        div.textContent = str;
        return div.innerHTML;
    }

    // Toast system (lightweight)
    function showToast(message, type = 'info', duration = 4000) {
        const container = document.getElementById('toastContainer');
        if (!container) return;
        const colors = { success: '#16a34a', error: '#ef4444', info: '#2563eb' };
        const toast = document.createElement('div');
        toast.className = `toast toast-${type}`;
        toast.style.background = colors[type] || colors.info;
        toast.innerHTML = `
            <span>${message}</span>
            <button class="toast-close" aria-label="Close toast">&times;</button>
        `;
        container.appendChild(toast);
        const closeBtn = toast.querySelector('.toast-close');
        closeBtn.addEventListener('click', () => toast.remove());
        setTimeout(() => { if (toast.parentNode) toast.remove(); }, duration);
    }

    fetchAbout();
});
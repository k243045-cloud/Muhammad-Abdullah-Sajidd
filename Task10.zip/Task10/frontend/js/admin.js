// admin.js - for admin panel

document.addEventListener('DOMContentLoaded', () => {
    const API_BASE = '/api/about';
    let quillDescription, quillMission, quillVision;

    // Ensure Quill is loaded (CDN)
    if (typeof Quill === 'undefined') {
        console.error('Quill library not loaded');
        return;
    }

    const pageContent = document.getElementById('pageContent');

    async function loadAdmin() {
        pageContent.innerHTML = `
            <div class="loading-overlay">
                <div class="spinner spinner-dark"></div>
                <span>Loading admin panel…</span>
            </div>
        `;

        try {
            const response = await fetch(API_BASE);
            const result = await response.json();
            if (!response.ok) throw new Error(result.message || 'Failed to load');
            const about = result.data || {};

            // Render form and preview
            pageContent.innerHTML = `
                <div class="admin-layout" style="display:grid; grid-template-columns:2fr 1fr; gap:28px;">
                    <!-- Form -->
                    <div class="card">
                        <div class="card-title"><span class="icon">✏️</span> Edit About Page</div>
                        <form id="aboutForm" novalidate>
                            <div class="form-group">
                                <label for="companyName">Company Name <span class="required">*</span></label>
                                <input type="text" id="companyName" class="form-control" value="${escapeHtml(about.company_name || '')}" placeholder="e.g. Acme Inc." required />
                            </div>
                            <div class="form-group">
                                <label>Description <span class="required">*</span></label>
                                <div class="quill-wrapper" id="descriptionEditor"></div>
                                <div class="form-hint">Write a compelling company description.</div>
                            </div>
                            <div class="form-group">
                                <label>Mission <span class="required">*</span></label>
                                <div class="quill-wrapper" id="missionEditor"></div>
                            </div>
                            <div class="form-group">
                                <label>Vision <span class="required">*</span></label>
                                <div class="quill-wrapper" id="visionEditor"></div>
                            </div>
                            <div class="form-group">
                                <label for="imageUrl">Image URL</label>
                                <input type="url" id="imageUrl" class="form-control" value="${escapeHtml(about.image_url || '')}" placeholder="https://example.com/photo.jpg" />
                                <div class="form-hint">Paste a direct image URL, or use the upload below.</div>
                            </div>
                            <div class="form-group">
                                <label>Or Upload Image</label>
                                <div class="file-input-wrapper" style="display:flex; gap:12px; align-items:center; flex-wrap:wrap;">
                                    <input type="file" id="imageFile" accept="image/*" style="flex:1; min-width:180px; padding:6px 0;" />
                                    <button type="button" class="btn btn-outline btn-sm" id="uploadBtn">📤 Upload</button>
                                </div>
                                <div id="imagePreview" class="image-preview-empty" style="margin-top:8px;">
                                    ${about.image_url ? `<img src="${about.image_url}" alt="Preview" style="max-width:100%; max-height:120px; border-radius:6px;" />` : 'No image set'}
                                </div>
                            </div>
                            <div class="form-actions" style="display:flex; gap:12px; margin-top:8px; flex-wrap:wrap;">
                                <button type="submit" class="btn btn-primary" id="saveBtn">💾 Save Changes</button>
                                <button type="button" class="btn btn-outline" onclick="resetForm()">↺ Reset</button>
                            </div>
                            <div id="formStatus" style="margin-top:12px; font-size:0.9rem;"></div>
                        </form>
                    </div>
                    <!-- Preview -->
                    <div class="card preview-card">
                        <div class="card-title"><span class="icon">👁️</span> Live Preview</div>
                        <div id="livePreview">
                            <div class="company-name-preview" style="font-size:1.4rem; font-weight:600;">${escapeHtml(about.company_name || 'Your Company')}</div>
                            <div class="preview-text" style="color:#334155; font-size:0.9rem; line-height:1.5; max-height:120px; overflow:hidden; text-overflow:ellipsis;">${about.description || 'No description yet.'}</div>
                            <div class="preview-mv" style="display:grid; grid-template-columns:1fr 1fr; gap:12px; margin-top:8px; font-size:0.85rem;">
                                <div><strong style="color:#64748b; font-weight:600; display:block; font-size:0.75rem; text-transform:uppercase; letter-spacing:0.04em;">Mission</strong><p style="margin:0; color:#1e293b;">${about.mission || 'Not set'}</p></div>
                                <div><strong style="color:#64748b; font-weight:600; display:block; font-size:0.75rem; text-transform:uppercase; letter-spacing:0.04em;">Vision</strong><p style="margin:0; color:#1e293b;">${about.vision || 'Not set'}</p></div>
                            </div>
                            ${about.image_url ? `<img src="${about.image_url}" alt="preview" style="max-width:100%; max-height:100px; border-radius:6px; margin-top:10px; object-fit:cover;" />` : ''}
                        </div>
                        <div style="margin-top:12px; font-size:0.8rem; color:#94a3b8;">
                            Updated: ${about.updated_at ? new Date(about.updated_at).toLocaleString() : 'Never'}
                        </div>
                    </div>
                </div>
            `;

            // Initialize Quill editors
            quillDescription = new Quill('#descriptionEditor', {
                theme: 'snow',
                placeholder: 'Tell your company story…',
                modules: {
                    toolbar: [
                        ['bold', 'italic', 'underline', 'strike'],
                        [{ 'list': 'ordered' }, { 'list': 'bullet' }],
                        ['link', 'clean']
                    ]
                }
            });
            quillMission = new Quill('#missionEditor', {
                theme: 'snow',
                placeholder: 'What is your mission?',
                modules: {
                    toolbar: [
                        ['bold', 'italic', 'underline'],
                        [{ 'list': 'ordered' }, { 'list': 'bullet' }],
                        ['clean']
                    ]
                }
            });
            quillVision = new Quill('#visionEditor', {
                theme: 'snow',
                placeholder: 'What is your vision?',
                modules: {
                    toolbar: [
                        ['bold', 'italic', 'underline'],
                        [{ 'list': 'ordered' }, { 'list': 'bullet' }],
                        ['clean']
                    ]
                }
            });

            // Set initial content
            quillDescription.root.innerHTML = about.description || '';
            quillMission.root.innerHTML = about.mission || '';
            quillVision.root.innerHTML = about.vision || '';

            // Live preview update
            const previewEl = document.getElementById('livePreview');
            const companyInput = document.getElementById('companyName');
            const imageUrlInput = document.getElementById('imageUrl');

            function updatePreview() {
                const name = companyInput.value || 'Your Company';
                const desc = quillDescription.root.innerHTML || 'No description yet.';
                const mission = quillMission.root.innerHTML || 'Not set';
                const vision = quillVision.root.innerHTML || 'Not set';
                const img = imageUrlInput.value || '';

                let imgHtml = '';
                if (img) {
                    imgHtml = `<img src="${img}" alt="preview" style="max-width:100%; max-height:100px; border-radius:6px; margin-top:10px; object-fit:cover;" />`;
                }

                previewEl.innerHTML = `
                    <div class="company-name-preview" style="font-size:1.4rem; font-weight:600;">${escapeHtml(name)}</div>
                    <div class="preview-text" style="color:#334155; font-size:0.9rem; line-height:1.5; max-height:120px; overflow:hidden; text-overflow:ellipsis;">${desc}</div>
                    <div class="preview-mv" style="display:grid; grid-template-columns:1fr 1fr; gap:12px; margin-top:8px; font-size:0.85rem;">
                        <div><strong style="color:#64748b; font-weight:600; display:block; font-size:0.75rem; text-transform:uppercase; letter-spacing:0.04em;">Mission</strong><p style="margin:0; color:#1e293b;">${mission}</p></div>
                        <div><strong style="color:#64748b; font-weight:600; display:block; font-size:0.75rem; text-transform:uppercase; letter-spacing:0.04em;">Vision</strong><p style="margin:0; color:#1e293b;">${vision}</p></div>
                    </div>
                    ${imgHtml}
                `;
            }

            companyInput.addEventListener('input', updatePreview);
            imageUrlInput.addEventListener('input', updatePreview);
            quillDescription.on('text-change', updatePreview);
            quillMission.on('text-change', updatePreview);
            quillVision.on('text-change', updatePreview);
            window._updatePreview = updatePreview;

            // Image preview on URL input
            const previewContainer = document.getElementById('imagePreview');
            imageUrlInput.addEventListener('input', () => {
                const val = imageUrlInput.value.trim();
                if (val) {
                    previewContainer.innerHTML = `<img src="${val}" alt="Preview" style="max-width:100%; max-height:120px; border-radius:6px;" />`;
                    previewContainer.className = 'image-preview';
                } else {
                    previewContainer.innerHTML = 'No image set';
                    previewContainer.className = 'image-preview-empty';
                }
            });

            // Image upload
            document.getElementById('uploadBtn').addEventListener('click', async () => {
                const fileInput = document.getElementById('imageFile');
                const file = fileInput.files[0];
                if (!file) {
                    showToast('Please select an image file first.', 'error');
                    return;
                }
                const formData = new FormData();
                formData.append('image', file);
                try {
                    const uploadBtn = document.getElementById('uploadBtn');
                    uploadBtn.disabled = true;
                    uploadBtn.textContent = '⏳ Uploading…';
                    const res = await fetch('/api/about/upload', {
                        method: 'POST',
                        body: formData,
                    });
                    const result = await res.json();
                    if (!res.ok) throw new Error(result.message || 'Upload failed');
                    imageUrlInput.value = result.data.imageUrl;
                    imageUrlInput.dispatchEvent(new Event('input'));
                    if (window._updatePreview) window._updatePreview();
                    showToast('Image uploaded successfully!', 'success');
                } catch (err) {
                    showToast('Upload error: ' + err.message, 'error');
                } finally {
                    const uploadBtn = document.getElementById('uploadBtn');
                    uploadBtn.disabled = false;
                    uploadBtn.textContent = '📤 Upload';
                    document.getElementById('imageFile').value = '';
                }
            });

            // Form submit
            document.getElementById('aboutForm').addEventListener('submit', async (e) => {
                e.preventDefault();
                const saveBtn = document.getElementById('saveBtn');
                const statusEl = document.getElementById('formStatus');

                const companyName = document.getElementById('companyName').value.trim();
                const description = quillDescription.root.innerHTML;
                const mission = quillMission.root.innerHTML;
                const vision = quillVision.root.innerHTML;
                const image_url = document.getElementById('imageUrl').value.trim();

                if (!companyName) { showToast('Company Name is required.', 'error'); document.getElementById('companyName').focus(); return; }
                if (!description || description === '<p><br></p>') { showToast('Description is required.', 'error'); return; }
                if (!mission || mission === '<p><br></p>') { showToast('Mission is required.', 'error'); return; }
                if (!vision || vision === '<p><br></p>') { showToast('Vision is required.', 'error'); return; }

                const payload = { company_name: companyName, description, mission, vision, image_url };

                saveBtn.disabled = true;
                saveBtn.innerHTML = '<span class="spinner"></span> Saving…';
                statusEl.textContent = '';

                try {
                    const res = await fetch(API_BASE, {
                        method: 'PUT',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify(payload),
                    });
                    const result = await res.json();
                    if (!res.ok) throw new Error(result.message || 'Update failed');
                    showToast('✅ About page updated successfully!', 'success');
                    statusEl.innerHTML = `<span style="color:#16a34a;">✅ ${result.message || 'Changes saved.'}</span>`;
                    // Update the updated_at in preview
                    if (result.data && result.data.updated_at) {
                        const updatedEl = document.querySelector('.preview-card div:last-child');
                        if (updatedEl) {
                            updatedEl.textContent = `Updated: ${new Date(result.data.updated_at).toLocaleString()}`;
                        }
                    }
                    if (window._updatePreview) window._updatePreview();
                } catch (err) {
                    showToast('❌ ' + err.message, 'error');
                    statusEl.innerHTML = `<span style="color:#ef4444;">❌ ${escapeHtml(err.message)}</span>`;
                } finally {
                    saveBtn.disabled = false;
                    saveBtn.innerHTML = '💾 Save Changes';
                }
            });

            // Initial preview update
            setTimeout(updatePreview, 100);
            showToast('📝 Edit your About page content below.', 'info', 3000);

        } catch (err) {
            pageContent.innerHTML = `
                <div class="card" style="text-align:center; padding:48px 20px;">
                    <div style="font-size:2.4rem; margin-bottom:12px;">⚠️</div>
                    <h2 style="color:#ef4444; font-weight:600;">Failed to load admin panel</h2>
                    <p style="color:#64748b; margin-top:6px;">${escapeHtml(err.message)}</p>
                    <button class="btn btn-primary mt-16" onclick="location.reload()">🔄 Retry</button>
                </div>
            `;
            showToast('Error loading admin panel: ' + err.message, 'error');
        }
    }

    // Reset form (global)
    window.resetForm = function() {
        const companyInput = document.getElementById('companyName');
        const imageUrlInput = document.getElementById('imageUrl');
        if (companyInput) companyInput.value = '';
        if (imageUrlInput) imageUrlInput.value = '';
        if (quillDescription) quillDescription.root.innerHTML = '';
        if (quillMission) quillMission.root.innerHTML = '';
        if (quillVision) quillVision.root.innerHTML = '';
        const previewContainer = document.getElementById('imagePreview');
        if (previewContainer) {
            previewContainer.innerHTML = 'No image set';
            previewContainer.className = 'image-preview-empty';
        }
        if (window._updatePreview) window._updatePreview();
        document.getElementById('formStatus').innerHTML = '';
        showToast('Form reset.', 'info', 2000);
    };

    // Toast system
    function showToast(message, type = 'info', duration = 4000) {
        const container = document.getElementById('toastContainer');
        if (!container) return;
        const colors = { success: '#16a34a', error: '#ef4444', info: '#2563eb' };
        const toast = document.createElement('div');
        toast.className = `toast toast-${type}`;
        toast.style.background = colors[type] || colors.info;
        toast.innerHTML = `
            <span>${message}</span>
            <button class="toast-close" aria-label="Close toast">&times;</button>
        `;
        container.appendChild(toast);
        const closeBtn = toast.querySelector('.toast-close');
        closeBtn.addEventListener('click', () => toast.remove());
        setTimeout(() => { if (toast.parentNode) toast.remove(); }, duration);
    }

    function escapeHtml(str) {
        if (!str) return '';
        const div = document.createElement('div');
        div.textContent = str;
        return div.innerHTML;
    }

    loadAdmin();
});
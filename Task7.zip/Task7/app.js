document.addEventListener('DOMContentLoaded', () => {
    const teamGrid = document.getElementById('team-grid');
    const loadingIndicator = document.getElementById('loading-state');
    const errorIndicator = document.getElementById('error-state');

    // Asynchronous network resource fetch strategy 
    async function fetchAndRenderTeam() {
        try {
            // Initiate fetch request pointing to our JSON file path target context
            const response = await fetch('team.json');
            
            // Critical Exception Check: Ensure network channel state resolves successfully
            if (!response.ok) {
                throw new Error(`HTTP network error query status resolved: ${response.status}`);
            }

            // Parse response content buffer arrays down to JSON matrix records
            const teamData = await response.json();
            
            // Flush loading indicator out of visual render layer
            loadingIndicator.classList.add('hidden');

            // Render array looping execution engine 
            renderTeamGrid(teamData);

        } catch (error) {
            console.error('Core engineering dynamic asset load failure logged:', error);
            loadingIndicator.classList.add('hidden');
            errorIndicator.classList.remove('hidden');
        }
    }

    // Dom element mapping constructor engine
    function renderTeamGrid(members) {
        let gridHTMLBuffer = '';    

        members.forEach(member => {
            gridHTMLBuffer += `
                <article class="team-card">
                    <div class="avatar-wrapper">
                        <img src="${member.image_url}" alt="${member.name} - Headshot portrait profile overview" loading="lazy">
                    </div>
                    <div class="profile-details">
                        <h3>${member.name}</h3>
                        <span class="role-badge">${member.role}</span>
                        <p class="bio-text">${member.bio}</p>
                        <div class="social-tray">
                            <a href="${member.social_links.linkedin}" class="social-item" target="_blank" rel="noopener noreferrer">LinkedIn</a>
                            <a href="${member.social_links.github}" class="social-item" target="_blank" rel="noopener noreferrer">GitHub</a>
                        </div>
                    </div>
                </article>
            `;
        });

        // Inject the generated HTML strings into the DOM container at once
        teamGrid.innerHTML = gridHTMLBuffer;
    }

    // Ignite operations pipeline
    fetchAndRenderTeam();
});
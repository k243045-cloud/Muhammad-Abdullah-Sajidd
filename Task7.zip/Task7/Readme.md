Task 7: Dynamic Team Page – Asynchronous JSON Fetching


# Task 7: Dynamic Team Page (JSON / API Driven)
 🎯 Objective
To eliminate manual code duplication by transforming the page layout into a decoupled, data-driven web interface. Content layer generation is managed by an asynchronous JavaScript operations engine that loops through a server-side JSON file data grid layout.

 🛠️ Key Technical Implementations
* **Decoupled Data Architecture:** Abstracted all corporate and partner data fields out of the markup page layer and organized them into a structured file repository (`team.json`).
* **Asynchronous Networking (`fetch` / `async-await`):** Designed non-blocking request pipelines using the modern Fetch API to pull local data packages over an active HTTP stream.
* **Error & Network State Interceptors:** Programmed defensive runtime state validation catchers to display informative loading indicators and error fallback configurations if the system goes offline.
* **Component Synthesis:** Built functional JavaScript template strings that render semantic component grids inside the DOM in a single rendering cycle.

 🗂️ Project Architecture

├── index.html       # Clean framework containing the script anchor endpoints
├── style.css        # Interactive grid layouts and styling rules
├── app.js           # Asynchronous network controller script
└── team.json        # Unified organizational relational records store

🗺️ Global Workspace Execution Blueprint
Step 1: Install the Live Server Extension in vs code
Step 2: Click the Go Live button at the bottom-right corner of VS Code.

🗺️ Why not with index.html:

When you double-click index.html, the browser opens it using the file:// protocol, for example:

file:///C:/Users/Abdullah/Desktop/Project/index.html

In this mode, browsers usually block fetch() from reading local files for security reasons. Your code:

fetch('team.json')

will fail with an error like:

Failed to fetch

or

Access to fetch at 'file:///...' has been blocked by CORS policy
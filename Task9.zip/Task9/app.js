document.addEventListener('DOMContentLoaded', () => {
    // Structural Node Tree Targets
    const partnerGrid = document.getElementById('partner-grid');
    const searchInput = document.getElementById('search-input');
    const filterButtons = document.querySelectorAll('.filter-btn');
    
    const loadingState = document.getElementById('loading-state');
    const errorState = document.getElementById('error-state');
    const emptyState = document.getElementById('empty-state');

    // Structural Modal Dialog Handle Targets
    const globalModalOverlay = document.getElementById('global-modal-overlay');
    const modalCloseTrigger = document.getElementById('modal-close-trigger');
    const modalDynamicContentRoot = document.getElementById('modal-dynamic-content-root');

    let corporateMasterDataset = [];
    let activeFilterCategory = 'All';
    let activeSearchString = '';

    // Asynchronously fetch raw corporate database configurations
    async function loadEcosystemRegistry() {
        try {
            const response = await fetch('team.json');
            if (!response.ok) throw new Error(`HTTP fetch error code: ${response.status}`);
            
            corporateMasterDataset = await response.json();
            loadingState.classList.add('hidden');
            processInterfaceFilters();
        } catch (error) {
            console.error('Data system synchronization link failure logged:', error);
            loadingState.classList.add('hidden');
            errorState.classList.remove('hidden');
        }
    }

    // Processing Filters Pipeline Logic Execution
    function processInterfaceFilters() {
        const matchingNodes = corporateMasterDataset.filter(node => {
            let matchesCategory = false;
            const cardRole = node.role.toLowerCase();

            if (activeFilterCategory === 'All') {
                matchesCategory = true;
            } else if (activeFilterCategory === 'Software') {
                matchesCategory = cardRole.includes('software development');
            } else if (activeFilterCategory === 'Consulting') {
                matchesCategory = cardRole.includes('consulting');
            } else if (activeFilterCategory === 'Data') {
                matchesCategory = cardRole.includes('data services');
            } else if (activeFilterCategory === 'AI') {
                matchesCategory = cardRole.includes('technology, information') || cardRole.includes('research services');
            }

            const sanitizedQuery = activeSearchString.toLowerCase().trim();
            const matchesSearch = sanitizedQuery === '' || 
                                  node.name.toLowerCase().includes(sanitizedQuery) ||
                                  node.role.toLowerCase().includes(sanitizedQuery) ||
                                  node.bio.toLowerCase().includes(sanitizedQuery);

            return matchesCategory && matchesSearch;
        });

        if (matchingNodes.length === 0) {
            partnerGrid.classList.add('hidden');
            emptyState.classList.remove('hidden');
        } else {
            emptyState.classList.add('hidden');
            partnerGrid.classList.remove('hidden');
            generateCardLayouts(matchingNodes);
        }
    }

    // Draw Main Card Infrastructure Links Layout
    function generateCardLayouts(elements) {
        let gridHTML = '';
        
        elements.forEach(item => {
            gridHTML += `
                <article class="corporate-card" data-entity-id="${item.id}">
                    <div class="brand-image-holder">
                        <img src="${item.image_url}" alt="${item.name} logo asset" loading="lazy">
                    </div>
                    <div class="card-body">
                        <h3>${item.name}</h3>
                        <span class="role-badge">${item.role}</span>
                        <p class="bio-desc">${item.bio}</p>
                        <div class="card-footer">
                            <button class="action-trigger-btn">Analyze Capabilities</button>
                        </div>
                    </div>
                </article>
            `;
        });
        partnerGrid.innerHTML = gridHTML;
    }

    // --- 3. Modal Core Lifecycle Controller System Management Methods ---
    
    function isolateAndLaunchModal(id) {
        // Run deep structural comparison search to retrieve target node object context data matches
        const activeTargetRecord = corporateMasterDataset.find(item => item.id === parseInt(id, 10));
        if (!activeTargetRecord) return;

        // Build expanded layout configuration string structure
        const targetViewMarkup = `
            <div class="modal-hero-banner">
                <img src="${activeTargetRecord.image_url}" alt="${activeTargetRecord.name} corporate header banner asset">
            </div>
            <div class="modal-body-content">
                <h2>${activeTargetRecord.name}</h2>
                <span class="role-badge">${activeTargetRecord.role}</span>
                <p class="extended-bio">${activeTargetRecord.bio}</p>
                <div class="modal-footer-links">
                    <a href="${activeTargetRecord.social_links.linkedin}" class="link-btn" target="_blank" rel="noopener noreferrer">LinkedIn Ecosystem Hub</a>
                    <a href="${activeTargetRecord.social_links.github}" class="link-btn" target="_blank" rel="noopener noreferrer">GitHub Workspace</a>
                </div>
            </div>
        `;

        // Inject compiled content view into display layer portal node tree
        modalDynamicContentRoot.innerHTML = targetViewMarkup;

        // Trigger presentation layers animations, unhide frame, lock outer body page scroll vectors
        globalModalOverlay.classList.remove('hidden');
        document.body.classList.add('scroll-lock');
    }

    function dismissActivePortalWindow() {
        globalModalOverlay.classList.add('hidden');
        document.body.classList.remove('scroll-lock');
        modalDynamicContentRoot.innerHTML = ''; // Clear memory references from HTML buffer tree
    }

    // --- Interaction Observers Integration Wireframes ---

    // Look for clicks across the card wrapper container to capture card choices cleanly
    partnerGrid.addEventListener('click', (e) => {
        const matchedCardContext = e.target.closest('.corporate-card');
        if (matchedCardContext) {
            const parsedTargetID = matchedCardContext.getAttribute('data-entity-id');
            isolateAndLaunchModal(parsedTargetID);
        }
    });

    // Close button dismiss action observer setup link
    modalCloseTrigger.addEventListener('click', dismissActivePortalWindow);

    // Click outside modal frame on back-drop dark overlay zone setup
    globalModalOverlay.addEventListener('click', (e) => {
        if (e.target === globalModalOverlay) {
            dismissActivePortalWindow();
        }
    });

    // Global physical keyboard Escape ('ESC') tracking stroke listener setup
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape' && !globalModalOverlay.classList.contains('hidden')) {
            dismissActivePortalWindow();
        }
    });

    // Filtering inputs control bindings
    searchInput.addEventListener('input', (e) => {
        activeSearchString = e.target.value;
        processInterfaceFilters();
    });

    filterButtons.forEach(btn => {
        btn.addEventListener('click', (e) => {
            filterButtons.forEach(element => element.classList.remove('active'));
            e.target.classList.add('active');
            activeFilterCategory = e.target.getAttribute('data-category');
            processInterfaceFilters();
        });
    });

    loadEcosystemRegistry();
});
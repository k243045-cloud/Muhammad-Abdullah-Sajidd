📑 Task 9: Interactive Capabilities Modal Popup Portal



Task 9: Partner Analytics & Capabilities Modal Popup Portal

🎯 Objective
To complete the system dashboard layout by adding a modal popup overlay portal. Clicking any corporate card displays full profile fields, deep capability matrices, and external link endpoints in a focused window without navigating away from the page.

 🛠️ Key Technical Implementations
* **Contextual Data Routing:** Programmed click listeners to capture distinct tracking parameters (`data-entity-id`), pull the matching partner object from memory, and build the custom view template dynamically.
* **Accessibility Layer Isolation:** Integrated focus trap parameters and a global event listener to capture keyboard events—allowing users to dismiss the open window seamlessly by pressing the **Escape (`ESC`) key**.
* **Viewport Scroll Locking:** Programmed dynamic window state shifts (`classList.toggle`) to append scrolling safety locks (`overflow: hidden`) onto the outer document body, preventing disruptive double-scrollbars.
* **Cinematic Interface Visuals:** Styled deep background blurs (`backdrop-filter: blur()`) using accelerated CSS transitions, alongside scaling keyframe animations that make the window slide up elegantly when opened.

 🗂️ Project Architecture

├── index.html       # Framework updated with structural overlay portal dialog anchors
├── style.css        # Added viewport overlays, animation rules, and modal styling
├── app.js           # Full interaction framework managing data routing and escape paths
└── team.json        # Master corporate enterprise data records repository


🗺️ Global Workspace Execution Blueprint
Step 1: Install the Live Server Extension in vs code
Step 2: Click the Go Live button at the bottom-right corner of VS Code.

🗺️ Why not with index.html:

When you double-click index.html, the browser opens it using the file:// protocol, for example:

file:///C:/Users/Abdullah/Desktop/Project/index.html

In this mode, browsers usually block fetch() from reading local files for security reasons. Your code:

fetch('team.json')

will fail with an error like:

Failed to fetch

or

Access to fetch at 'file:///...' has been blocked by CORS policy
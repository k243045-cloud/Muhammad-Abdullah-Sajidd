# Task 2: Product Filter System with Dynamic Search

## 🎯 Objective
Construct an interactive client-side Product Filter Matrix. This interface provides users with the ability to query a product catalog in real-time through an input text bar or by toggling category category filters dynamically.

## 🛠 Features
* **Real-Time Input Filtering:** Instantly screens product card text matching incoming keystrokes.
* **Category Button Controls:** Filter data arrays down to target selections instantly.
* **Active Button States:** Clear visual indicator showing which category filter is currently active.
* **Empty Search Fallbacks:** Handles unmatched search terms gracefully with a clean "No items match your criteria" notice.

## 📁 Project Structure
```text
├── data/team.json
├── public/index.html , admin.html
├── server.js
└── package.json

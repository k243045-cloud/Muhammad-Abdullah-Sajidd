const express = require('express');
const fs = require('fs');
const path = require('path');
const app = express();
const PORT = 3000;

const DATA_FILE = path.join(__dirname, 'data', 'team.json');

app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// Helper functions to read/write JSON
const readData = () => JSON.parse(fs.readFileSync(DATA_FILE, 'utf8'));
const writeData = (data) => fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2));

// API: Get all team members
app.get('/api/team', (req, res) => {
    try { res.json(readData()); } catch (err) { res.status(500).json({ error: "Read error" }); }
});

// API: Add team member
app.post('/api/team', (req, res) => {
    const data = readData();
    const newMember = { id: Date.now(), ...req.body };
    data.push(newMember);
    writeData(data);
    res.status(201).json(newMember);
});

// API: Update team member
app.put('/api/team/:id', (req, res) => {
    const data = readData();
    const id = parseInt(req.params.id);
    const index = data.findIndex(m => m.id === id);
    if (index !== -1) {
        data[index] = { id, ...req.body };
        writeData(data);
        res.json(data[index]);
    } else {
        res.status(404).json({ error: "Member not found" });
    }
});

// API: Delete team member
app.delete('/api/team/:id', (req, res) => {
    let data = readData();
    const id = parseInt(req.params.id);
    data = data.filter(m => m.id !== id);
    writeData(data);
    res.json({ message: "Member deleted successfully" });
});

app.listen(PORT, () => console.log(`Server running at http://localhost:${PORT}`));
document.addEventListener('DOMContentLoaded', () => {
    const API_URL = '/api/services';
    const container = document.getElementById('servicesContainer');
    const categoryFilter = document.getElementById('categoryFilter');
    const searchInput = document.getElementById('searchInput');
    const searchBtn = document.getElementById('searchBtn');
    const clearBtn = document.getElementById('clearBtn');

    let allServices = [];
    let categories = [];

    // Fetch services with optional filters
    async function fetchServices(params = {}) {
        const query = new URLSearchParams(params).toString();
        const url = API_URL + (query ? '?' + query : '');
        try {
            const response = await fetch(url);
            if (!response.ok) throw new Error('Failed to fetch');
            const data = await response.json();
            if (!data.success) throw new Error(data.message || 'Unknown error');
            allServices = data.data;
            categories = data.meta.categories || [];
            return allServices;
        } catch (err) {
            console.error(err);
            showError(err.message);
            return [];
        }
    }

    function renderServices(services) {
        if (!services || services.length === 0) {
            container.innerHTML = `
                <div class="no-results">
                    <div class="icon">🔍</div>
                    <p>No services found matching your criteria.</p>
                </div>
            `;
            return;
        }

        let html = '<div class="services-grid">';
        services.forEach(service => {
            html += `
                <div class="service-card">
                    <img class="card-img" src="${service.image_url || 'https://via.placeholder.com/400x300/1e293b/94a3b8?text=No+Image'}" alt="${service.title}" loading="lazy" />
                    <div class="card-body">
                        <div class="card-title">${escapeHtml(service.title)}</div>
                        <span class="card-category">${escapeHtml(service.category || 'General')}</span>
                        <p class="card-description">${escapeHtml(service.description)}</p>
                    </div>
                </div>
            `;
        });
        html += '</div>';
        container.innerHTML = html;
    }

    function showError(message) {
        container.innerHTML = `
            <div class="no-results" style="color:#f87171;">
                <div class="icon">⚠️</div>
                <p>Error loading services: ${escapeHtml(message)}</p>
                <button onclick="location.reload()" style="margin-top:12px; padding:8px 20px; border:none; background:#3b82f6; color:#fff; border-radius:8px; cursor:pointer;">Retry</button>
            </div>
        `;
    }

    function escapeHtml(str) {
        if (!str) return '';
        const div = document.createElement('div');
        div.textContent = str;
        return div.innerHTML;
    }

    // Populate category filter
    function populateCategories(cats) {
        categoryFilter.innerHTML = '<option value="">All</option>';
        cats.forEach(cat => {
            const opt = document.createElement('option');
            opt.value = cat;
            opt.textContent = cat;
            categoryFilter.appendChild(opt);
        });
    }

    // Apply filters and re‑render
    async function applyFilters() {
        const category = categoryFilter.value;
        const search = searchInput.value.trim();
        // We can either re‑fetch with filters or filter client‑side.
        // For demonstration, we'll fetch filtered from backend.
        const params = {};
        if (category) params.category = category;
        if (search) params.search = search;
        // Optional: limit/offset for pagination (not implemented)
        container.innerHTML = `<div class="loading-overlay"><div class="spinner"></div><span>Loading…</span></div>`;
        const services = await fetchServices(params);
        renderServices(services);
    }

    // Initial load
    async function init() {
        const services = await fetchServices();
        renderServices(services);
        populateCategories(categories);
    }

    // Event listeners
    categoryFilter.addEventListener('change', applyFilters);
    searchBtn.addEventListener('click', applyFilters);
    searchInput.addEventListener('keyup', (e) => {
        if (e.key === 'Enter') applyFilters();
    });
    clearBtn.addEventListener('click', () => {
        categoryFilter.value = '';
        searchInput.value = '';
        applyFilters();
    });

    init();
});
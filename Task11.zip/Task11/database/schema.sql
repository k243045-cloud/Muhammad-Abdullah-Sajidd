-- Create database
CREATE DATABASE IF NOT EXISTS services_db;
USE services_db;

-- Create services table
CREATE TABLE IF NOT EXISTS services (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    description TEXT NOT NULL,
    image_url VARCHAR(512),
    category VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Insert sample services with real, working image URLs
INSERT INTO services (title, description, image_url, category) VALUES
('Web Development', 'We build responsive, high-performance websites using modern frameworks like React, Vue, and Node.js.', 'https://images.unsplash.com/photo-1498050108023-c5249f4df085?w=400&h=300&fit=crop', 'Development'),
('Mobile App Design', 'User-centric mobile app design for iOS and Android with a focus on UX and delightful interactions.', 'https://images.unsplash.com/photo-1512941937669-90a1b58e7e9c?w=400&h=300&fit=crop', 'Design'),
('Cloud Solutions', 'Scalable cloud infrastructure and migration services for enterprises, using AWS, Azure, and GCP.', 'https://images.unsplash.com/photo-1451187580459-43490279c0fa?w=400&h=300&fit=crop', 'Infrastructure'),
('Digital Marketing', 'SEO, social media, and content marketing to boost your online presence and drive sales.', 'https://images.unsplash.com/photo-1432888622747-4eb9a8f2c9c3?w=400&h=300&fit=crop', 'Marketing'),
('Data Analytics', 'Turn raw data into actionable insights with our analytics services, using AI and visualization tools.', 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=400&h=300&fit=crop', 'Data'),
('AI & Machine Learning', 'Custom AI models and ML solutions to automate and optimize your business processes.', 'https://images.unsplash.com/photo-1555949963-aa79dcee981c?w=400&h=300&fit=crop', 'Development'),
('UI/UX Consulting', 'Expert consultation to improve your product’s usability and user satisfaction through research and testing.', 'https://images.unsplash.com/photo-1561070791-2526d30994b5?w=400&h=300&fit=crop', 'Design'),
('DevOps Services', 'Streamline your development pipeline with continuous integration, deployment, and monitoring.', 'https://images.unsplash.com/photo-1667372393119-3d4c48d07fc9?w=400&h=300&fit=crop', 'Infrastructure');
const db = require('../config/db');

class Services {
    // Get all services, optionally filtered by category and search
    static async getAll({ category, search, limit, offset } = {}) {
        let query = 'SELECT * FROM services';
        const params = [];
        const conditions = [];

        if (category) {
            conditions.push('category = ?');
            params.push(category);
        }
        if (search) {
            conditions.push('(title LIKE ? OR description LIKE ?)');
            const like = `%${search}%`;
            params.push(like, like);
        }

        if (conditions.length > 0) {
            query += ' WHERE ' + conditions.join(' AND ');
        }

        query += ' ORDER BY created_at DESC';

        if (limit) {
            query += ' LIMIT ?';
            params.push(parseInt(limit));
            if (offset) {
                query += ' OFFSET ?';
                params.push(parseInt(offset));
            }
        }

        const [rows] = await db.query(query, params);
        return rows;
    }

    // Get distinct categories (for filter)
    static async getCategories() {
        const [rows] = await db.query('SELECT DISTINCT category FROM services ORDER BY category');
        return rows.map(row => row.category);
    }
}

module.exports = Services;
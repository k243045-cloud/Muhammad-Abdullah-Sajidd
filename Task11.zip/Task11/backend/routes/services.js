const express = require('express');
const router = express.Router();
const Services = require('../models/Services');

// GET /api/services
router.get('/', async (req, res) => {
    try {
        const { category, search, limit, offset } = req.query;
        const services = await Services.getAll({ category, search, limit, offset });
        const categories = await Services.getCategories();
        res.json({
            success: true,
            data: services,
            meta: {
                categories,
                total: services.length // for simplicity; you could count separately
            }
        });
    } catch (err) {
        console.error(err);
        res.status(500).json({ success: false, message: 'Server error' });
    }
});

module.exports = router;
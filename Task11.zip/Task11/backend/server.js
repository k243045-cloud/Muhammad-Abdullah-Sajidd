require('dotenv').config();
const express = require('express');
const cors = require('cors');
const path = require('path');
const servicesRoutes = require('./routes/services');

const app = express();
const PORT = process.env.PORT || 5000;

app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Serve static frontend files
app.use(express.static(path.join(__dirname, '../frontend')));

// API route
app.use('/api/services', servicesRoutes);

app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});
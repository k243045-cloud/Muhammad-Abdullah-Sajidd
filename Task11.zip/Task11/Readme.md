# 📌 Dynamic Services Listing with Database Integration

A full‑stack web application that displays a dynamic list of services stored in a MySQL database. Features include category filtering, search, and the ability to upload custom images from your PC.

---

## ✨ Features

- ✅ **Dynamic service cards** – all content fetched from the database.
- ✅ **Category filter** – filter services by category.
- ✅ **Search functionality** – search by title or description.
- ✅ **Image upload** – upload custom images from your PC for each service.
- ✅ **Responsive grid** – adapts to any screen size.
- ✅ **Modern dark theme** – glassmorphism, hover effects, smooth animations.
- ✅ **RESTful API** – clean `/api/services` endpoint with query params.
- ✅ **Admin upload page** – easy interface to update service images.

---

## 🛠 Tech Stack

| Layer          | Technology                                      |
|----------------|-------------------------------------------------|
| **Frontend**   | HTML, CSS (dark theme), Vanilla JavaScript      |
| **Backend**    | Node.js, Express.js                             |
| **Database**   | MySQL (with promise‑based queries)              |
| **File Upload**| Multer                                          |
| **Environment**| dotenv                                          |

---

## 🚀 Setup Instructions

### 1. Prerequisites

- **Node.js** (v14 or later) – [Download](https://nodejs.org)
- **MySQL** (v5.7 or later) – [Download](https://dev.mysql.com/downloads/)
- A MySQL client (Workbench, phpMyAdmin, or terminal)

2. Database Setup
Open your MySQL client and run the SQL script from database/schema.sql.

You can also manually execute:

CREATE DATABASE IF NOT EXISTS cms_about;
USE cms_about;

CREATE TABLE IF NOT EXISTS about (
    id INT AUTO_INCREMENT PRIMARY KEY,
    company_name VARCHAR(255) NOT NULL,
    description TEXT NOT NULL,
    mission TEXT NOT NULL,
    vision TEXT NOT NULL,
    image_url VARCHAR(512),
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

INSERT INTO about (company_name, description, mission, vision, image_url)
VALUES (
    'Your Company Name',
    'Welcome to our company. We are dedicated to providing the best services.',
    'To empower every person and organization on the planet to achieve more.',
    'A world where technology enhances human potential.',
    'https://via.placeholder.com/600x400'
);

3. Backend Configuration
Open a terminal and navigate to the backend folder:

bash
cd backend
Install dependencies:

bash
npm install
Create a .env file in the backend folder with your credentials:

env
DB_HOST=localhost
DB_USER=root
DB_PASSWORD=your_mysql_password   # leave empty if no password
DB_NAME=cms_about
PORT=5000
If you skip the .env file, the defaults are: host localhost, user root, password '', database cms_about.

Ensure the uploads folder exists inside backend (it will be created automatically the first time you upload an image, but you can create it manually to be safe).

4. Running the Application
Start the backend server:

bash
npm start
For development with auto‑restart:

bash
npm run dev
You should see:

text
Database initialized successfully.
Server running on http://localhost:5000
Open your browser and visit:

Public About Page: http://localhost:5000/about.html

Admin Panel: http://localhost:5000/admin.html


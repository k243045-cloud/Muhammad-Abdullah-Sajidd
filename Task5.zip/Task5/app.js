document.addEventListener('DOMContentLoaded', () => {
    // Structural Element Selectors
    const menuToggle = document.querySelector('.menu-toggle');
    const navMenu = document.querySelector('.nav-menu');
    const navLinks = document.querySelectorAll('.nav-link');
    const navbar = document.querySelector('.navbar');
    const progressBar = document.getElementById('scroll-progress');
    const sections = document.querySelectorAll('.target-section');

    // --- 1. Mobile Menu Open / Close Handler ---
    function toggleMenu() {
        const isExpanded = menuToggle.getAttribute('aria-expanded') === 'true';
        menuToggle.setAttribute('aria-expanded', !isExpanded);
        menuToggle.classList.toggle('active');
        navMenu.classList.toggle('active');
    }

    menuToggle.addEventListener('click', toggleMenu);
    navLinks.forEach(link => link.addEventListener('click', () => {
        if (navMenu.classList.contains('active')) toggleMenu();
    }));

    // --- 2. Advanced Performance: Active Link Highlighting (Intersection Observer) ---
    // Scans screen changes dynamically; when 60% of a section occupies the viewport, it registers active.
    const observerOptions = {
        root: null,
        rootMargin: '-20% 0px -40% 0px', 
        threshold: 0
    };

    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const id = entry.target.getAttribute('id');
                
                navLinks.forEach(link => {
                    if (link.getAttribute('href') === `#${id}`) {
                        link.classList.add('active');
                    } else {
                        link.classList.remove('active');
                    }
                });
            }
        });
    }, observerOptions);

    sections.forEach(section => observer.observe(section));

    // --- 3. Scroll Dynamics: Navbar Modifications & Progress Meter Tracking ---
    window.addEventListener('scroll', () => {
        const scrollTop = window.scrollY;
        const docHeight = document.documentElement.scrollHeight - window.innerHeight;
        
        // Dynamic progress calculation metric
        const scrollPercent = docHeight > 0 ? (scrollTop / docHeight) * 100 : 0;
        progressBar.style.width = `${scrollPercent}%`;

        // Navbar structural background styling mutation triggers
        if (scrollTop > 50) {
            navbar.classList.add('scrolled');
        } else {
            navbar.classList.remove('scrolled');
        }
    }, { passive: true }); // passive flag optimizes scrolling execution on mobile engines
});
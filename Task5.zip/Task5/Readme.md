# Task 5: Sticky Navbar with Smooth Scroll & Active Highlight

## 🎯 Objective
Build a real-world page navigation framework featuring a fixed position header, smooth inner-page scrolling transitions, and active navigation link tracking based on live viewport scroll positions.

## 🛠 Features
* **Intersection Observer Tracking:** Uses a modern browser observer API to highlight active links with maximum performance instead of performance-heavy scroll listeners.
* **Smooth Scroll Transitions:** Provides a polished user experience using CSS `scroll-behavior: smooth` rules.
* **Scroll Progress Line:** Features a 3px top indicator tracking line that fills out as the user reads down the page.
* **Scroll Mutation Styles:** The navbar gains a background color blur and shadow depth mutation as soon as the user scrolls past the top 50px mark.
* **Scroll Padding Protection:** Includes top offset padding values to prevent the sticky navbar from covering titles when jumping down the page.

## 📁 Project Structure
```text
├── index.html
├── style.css
└── app.js
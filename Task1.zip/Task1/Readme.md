# Task 1: Profile Card Component with Hover Interactions

## 🎯 Objective

Design and implement a highly polished, responsive Profile Card component using HTML and CSS. The primary focus is semantic design structure and interactive hover micro-animations to enhance user engagement.

## 🛠 Features

* **Semantic DOM Elements:** Implemented cleanly using modern semantic HTML elements (`<article>`, `<figure>`, `<section>`, etc.).
* **Micro-Interactions:** Hovering over the component triggers smooth scaling shifts and depth drop-shadow adjustments.
* **Social Link Button Highlights:** Features clean transition loops for interactive icon links.
* **Fluid Typography:** Layout content adapts naturally across viewport scales.

## 📁 Project Structure

```text
├── index.html
└── style.css


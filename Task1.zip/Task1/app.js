// Dynamic slide data mimicking a backend database/JSON fetch
const slideData = [
    {
        title: "Next-Gen AI Demo Platform",
        description: "Experience machine learning interfaces optimized for extreme speed and granular data telemetry tracking.",
        image: "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=1920&q=80",
        ctaText: "Launch Application",
        ctaLink: "#"
    },
    {
        title: "Premium Web Architecture",
        description: "Tailored e-commerce and portfolio systems built with cutting-edge frameworks for modern web performance.",
        image: "https://images.unsplash.com/photo-1634017839464-5c339ebe3cb4?auto=format&fit=crop&w=1920&q=80",
        ctaText: "View Case Study",
        ctaLink: "#"
    },
    {
        title: "Immersive UI/UX Design",
        description: "Where aesthetic interactions meet clinical usability standards. Check out our latest mobile application designs.",
        image: "https://images.unsplash.com/photo-1600132806370-bf17e65e942f?auto=format&fit=crop&w=1920&q=80",
        ctaText: "Explore Design Lab",
        ctaLink: "#"
    }
];

let currentIndex = 0;
let slideInterval;
const AUTO_DELAY = 5000; // 5 seconds rotation

const sliderContainer = document.getElementById('slider-container');
const indicatorsContainer = document.getElementById('indicators-container');
const prevBtn = document.getElementById('prev-btn');
const nextBtn = document.getElementById('next-btn');

// 1. Initialize and Render Slider
function initSlider() {
    slideData.forEach((slide, index) => {
        // Create Slide Elements
        const slideEl = document.createElement('div');
        slideEl.classList.add('slide');
        if (index === 0) slideEl.classList.add('active');

        slideEl.innerHTML = `
            <div class="absolute inset-0 bg-gradient-to-r from-black/80 via-black/50 to-transparent z-20"></div>
            <img src="${slide.image}" alt="${slide.title}" class="w-full h-full object-cover transition-transform duration-[6000ms]">
            <div class="absolute inset-0 flex items-center z-30 max-w-7xl mx-auto px-6">
                <div class="slide-content max-w-2xl space-y-6">
                    <span class="text-cyan-400 font-bold uppercase tracking-widest text-sm">Featured Work</span>
                    <h1 class="text-4xl md:text-6xl font-extrabold tracking-tight leading-none">${slide.title}</h1>
                    <p class="text-gray-300 text-lg md:text-xl font-light">${slide.description}</p>
                    <div>
                        <a href="${slide.ctaLink}" class="inline-block bg-cyan-500 hover:bg-cyan-400 text-black font-semibold px-8 py-3 rounded shadow-lg transform hover:-translate-y-0.5 hover:scale-105 transition-all duration-300">
                            ${slide.ctaText}
                        </a>
                    </div>
                </div>
            </div>
        `;
        sliderContainer.appendChild(slideEl);

        // Create Indicators
        const dot = document.createElement('button');
        dot.className = `w-3 h-3 rounded-full transition-all duration-300 ${index === 0 ? 'bg-cyan-400 w-8' : 'bg-gray-500 hover:bg-gray-400'}`;
        dot.setAttribute('aria-label', `Go to slide ${index + 1}`);
        dot.addEventListener('click', () => goToSlide(index));
        indicatorsContainer.appendChild(dot);
    });

    startAutoRotate();
}

// 2. Change Slide Core Logic
function updateSliderDOM() {
    const slides = document.querySelectorAll('.slide');
    const dots = indicatorsContainer.children;

    slides.forEach((slide, index) => {
        if (index === currentIndex) {
            slide.classList.add('active');
            dots[index].classList.remove('bg-gray-500', 'w-3');
            dots[index].classList.add('bg-cyan-400', 'w-8');
        } else {
            slide.classList.remove('active');
            dots[index].classList.remove('bg-cyan-400', 'w-8');
            dots[index].classList.add('bg-gray-500', 'w-3');
        }
    });
}

function nextSlide() {
    currentIndex = (currentIndex + 1) % slideData.length;
    updateSliderDOM();
}

function prevSlide() {
    currentIndex = (currentIndex - 1 + slideData.length) % slideData.length;
    updateSliderDOM();
}

function goToSlide(index) {
    currentIndex = index;
    updateSliderDOM();
    resetTimer();
}

// 3. Timer Control Functions
function startAutoRotate() {
    slideInterval = setInterval(nextSlide, AUTO_DELAY);
}

function resetTimer() {
    clearInterval(slideInterval);
    startAutoRotate();
}

// 4. Event Listeners & Controls Override
nextBtn.addEventListener('click', () => {
    nextSlide();
    resetTimer();
});

prevBtn.addEventListener('click', () => {
    prevSlide();
    resetTimer();
});

// Keyboard Navigation for Accessibility
document.addEventListener('keydown', (e) => {
    if (e.key === "ArrowRight") {
        nextSlide();
        resetTimer();
    } else if (e.key === "ArrowLeft") {
        prevSlide();
        resetTimer();
    }
});

// Initialize on Load
document.addEventListener('DOMContentLoaded', initSlider);
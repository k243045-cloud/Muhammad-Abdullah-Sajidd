# Task 4: Dark/Light Mode with Local Storage Persistence

## 🎯 Objective
Implement a persistent structural Theme Toggle System that gives users the power to switch between light and dark palettes. The configuration saves locally to keep their choice active even after reloading the page.

## 🛠 Features
* **No Layout Flash (Zero Flicker):** Uses an inline script guard inside the document `<head>` to process themes *before* the body page loads.
* **CSS Variable Scoping:** Centralized palette control using CSS custom property mappings hooked to a `data-theme` attribute token.
* **Local Storage Integration:** Saves user selections directly to the browser storage layer.
* **System Preference Syncing:** Automatically falls back to the user's operating system dark/light configuration if no manual choice is found.

## 📁 Project Structure
```text
├── index.html
├── style.css
└── app.js